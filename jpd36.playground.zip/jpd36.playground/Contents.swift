/* Jonathan Pham
 * CS 4220 iOS
 * 06/23/19
 */

import Foundation
import Swift

/* Problem 1
 Write a function that:
 - takes in an Array of Ints
 - separates them into odd and even numbers
 - sorts both lists of numbers
 - and then returns the sorted evens and odds as a tuple
 
 Notes:
 - Research how to return multiple values (as a named tuple) from Swift functions
 - Do not manually sort the integers; find a better way!
 */

func sortedEvenOdd (numbers: [Int]) -> (evens: [Int] , odds:[Int]) {
    var evenNum : [Int] = []
    var oddNum : [Int] = []
    
    let sorted = numbers.sorted()
    
    for myInt in sorted {
        if ( myInt % 2 == 0 ) {
            evenNum.append(myInt)
            
        } else {
            oddNum.append(myInt)
        }
    }
    return (evenNum, oddNum)
}

print ("***** Project 1, Part 1 *****")
let numbers = [0, 9, 3, 7, 8, 15, 11, 2, 20]
let sortedEvenOdd = numbers.sorted()
let sorted = sortedEvenOdd

let sortedNumbers = sortedEvenOdd(numbers:[0, 9, 3, 7, 8, 15, 11, 2, 20])
print (sortedNumbers.evens)
print (sortedNumbers.odds)
print()


/* Problem 2
 Write a function that:
 - takes in two parameters: an Array of Strings and a String to find
 - locates the index of the string to find, if it exists in the array
 - returns an optional string one position later in the array than the string to find
 Notes:
 - if the string to find is at the end of the array, return the string at the beginning of the array
 - consult Apple's documentation to find a method on Array that will locate the index of a given element - do not loop through the array to find it.
 - if you encounter any optional values, unwrap them properly
 */

/* The function protocol takes in a string and an array of Strings
 and returns a string if the array is not empty */


func findNextItem (from:String, input:[String] ) -> String? {
    let arrayIndex = input.index( of:from )
    let arrayCounter = input.count
    if ( arrayIndex != nil ) {
        if ( arrayIndex == arrayCounter - 1 ) {
            return input[0] // Return first array index if current array index is the last
        }
        else {
            return input[ ( arrayIndex! + 1 ) ] // Move to next array index and return
        }
    }
    else {
        return nil // Return nil if String array is empty
    }
}

let bucketList = ["Travel to Antarctica", "Climb Mount Everest", "Run a marathon", "Write a book", "Build an iOS app"]

let item1 = findNextItem(from: "Write a book", input: bucketList)
let item2 = findNextItem(from: "Build an iOS app", input:bucketList)
let item3 = findNextItem(from: "Run a marathon", input: [])

print ("***** Project 1, Part 2 *****")
print(item1!) // "Build an iOS app"
print(item2!) // "Travel to Antarctica"
print(item3)  // nil
print()


/* Problem 3
 Write a function that generates a url string for making an HTTP GET request. It should match the call signature of the example calls below.
 - Look at the example output for how you need to construct your function.
 - Do not worry about any encoding issues; if there is a space in a parameter's key or value, just remove it
 - I will not use any harder examples to grade than in the example calls below
 - The order the parameters appear in the query string is not important
 */

func httpGetUrl ( baseUrl: String , parameters : [ String:String ] ) -> String {
    
    var httpCounter : Int = 1
    var httpResult : String = baseUrl
    
    if (parameters.count > 0) {
        httpResult +=  "?"
        for (key, value) in parameters {
            let keyString:String = key.replacingOccurrences (of: " ", with: "") //Remove space
            let valueString:String = value.replacingOccurrences (of: " ", with: "")
            if (httpCounter < parameters.count) {
                httpResult += keyString + "=" + valueString + "&"
            }
            else {
                httpResult += keyString + "=" + valueString + "&"
            }
            httpCounter += 1
        }
    }
    return httpResult.lowercased()
}

let url1 = httpGetUrl(baseUrl: "http://boardgames.com/game", parameters: ["Genre":"Strategy", "name":"Settlers Of Catan", "User Rating":"high"])
let url2 = httpGetUrl(baseUrl: "http://boardgames.com/game", parameters: [:])

print ("***** Project 1, Part 3 *****")
print(url1)
print(url2)
print()


/* Problem 4
 Write a function that takes in a camel-case string and returns an integer representing the number of words in the string
 
 Notes:
 - Assume all input will contain only letters, and the string will be a valid camel-cased phrase
 - Do not loop through the array manually.
 */

func camelCaseWordCount ( for camelString:String ) -> ( Int ) {
    
    var camelCounter:Int
    var camelCaseOutput = ""
    
    for start in camelString  {
        let camelLength = String(start)
        if ( camelLength.lowercased() != camelLength ) {
            camelCaseOutput += camelLength
        }
    }
    
    camelCounter = camelCaseOutput.count
    return camelCounter + 1 // +1 to account for first lowerCase word
}

print ("***** Project 1, Part 4 *****")
let camelCasePhraseOne = "camelCasePhraseOne"
let camelCasePhraseTwo = "aMuchLongerCamelCasePhraseThatIsWayWayWayMoreFunToTest"

print (camelCaseWordCount(for: camelCasePhraseOne))    // 4
print (camelCaseWordCount(for: camelCasePhraseTwo))    // 15
print ()


func primePrimes ( from startPrimeRange: Int, to endPrimeRange: Int ) {
    var primeLoopStartRange = startPrimeRange
    let primeLoopEndRange = endPrimeRange
    if ( startPrimeRange < 3 ) {
        primeLoopStartRange = 3
        print ( 2, terminator: ", " ) //Prints 2 if starting range is less than 3
    }
    for i in primeLoopStartRange...primeLoopEndRange { //Initialize primeLoop to 3
        var primeFlag = 0
        for j in 2..<i {
            if ( i % j == 0 ) {
                primeFlag = 1
            }
        }
        if ( primeFlag == 0 ) {
            print ( i, terminator: ", " )
        }
    }
}

print ("***** Project 1, Part 5 *****")
primePrimes ( from: 0, to: 100 )
print()



